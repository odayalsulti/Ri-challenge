import cv2
import pytesseract
import os
import re
import datetime
import numpy as np

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


# function read the image and pass to tessaract ocr
# and return the text of the image
def getAllTextFromImage(path):
    if os.path.exists(path):
        # cv2 read the image
        img = cv2.imread(path)
        # return the converted text
        return pytesseract.image_to_string(img)

    else:
        print("the image not found in your given path")
        return 0

# get a month in string give its number
def month_string_to_number(string):
    m = {
        'jan': 1,
        'feb': 2,
        'mar': 3,
        'apr':4,
         'may':5,
         'jun':6,
         'jul':7,
         'aug':8,
         'sep':9,
         'oct':10,
         'nov':11,
         'dec':12
        }
    s = string.strip()[:3].lower()

    try:
        out = m[s]
        return out
    except:
        raise ValueError('Not a month')


# method that takes the text as input and return all the dates
def GetAllDatesFromText(text):
    dates = []

    # match dates in 10/22/2222 format
    match = re.findall(r"[\d]{2}/[\d]{2}/[\d]{4}", text)
    # match dates in 10 aprail 22222 format
    textMatch = re.findall(r"[\d]{1,2} [ADFJMNOS]\w* [\d]{4}", text)

    for date in match:
        formated_date = datetime.datetime.strptime(date, "%d/%m/%Y").strftime("%Y-%m-%d")
        dates.append(formated_date)

    for date in textMatch:
        day , month , year = date.split(" ")
        new_date = f'{day}/{month_string_to_number(month)}/{year}'
        formated_date  = datetime.datetime.strptime(new_date, "%d/%m/%Y").strftime("%Y-%m-%d")
        dates.append(formated_date)

    print("---------------------- Dates in text  ------------------------")
    print(dates)



# method that takes the text as input and return all the emails
def GetAllEmailsFromText(text):
    emails = []
    match = re.findall(r'[\w\.-]+@[\w\.-]+', text)
    for email in match:
        emails.append(email)

    print("----------------------Emails in text  ------------------------")
    print(emails)

# get list of all room names
def GetAllRoomsNames(text):
    rooms = []
    match = re.findall(r'Room: [a-zA-z]*',text)
    for room in match:
        room_heading , room_name = room.split(" ")
        rooms.append(room_name)

    print("---------------------- Room names in text  ------------------------")
    print(rooms)


#  get list of all rooms rates
def GetAllRoomsRates(text):
    rates = []
    match = re.findall(r'(?:[\£\$\€]{1}[,\d]+.?\d*)' , text)
    for rate in match:
        rates.append(rate)
    print("---------------------- rates in text  ------------------------")
    print(rates)


# get all the indivdual names from text
def GetALLIndividualNamesFromText(text):
    names = []
    match  = re.findall(r'[:;]\s*(.+?)\s*<', text)
    for name in match:
        names.append(name)

    print("---------------------- Individual names in text  ------------------------")
    print(names)


text = getAllTextFromImage("rihal.jpg")
print("------------------ Entire text from image extracted  ---------------------")
print(text)
GetAllDatesFromText(text)
GetAllRoomsNames(text)
GetAllRoomsRates(text)
GetALLIndividualNamesFromText(text)
GetAllEmailsFromText(text)
